﻿namespace UTS.Models
{
    public class horario_agendaModel
    {
        public int idhorario { get; set; }

        public int idaula2 { get; set; }

        public bool apartado { get; set; }

        public string dia { get; set; }

        public string mes { get; set; }

        public string? years { get; set; }

        public string hora { get; set; }



    }
}
